package Movie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieDaoImpl implements MovieDao{


    public MovieDaoImpl() {}

    protected Connection getConnection() throws SQLException {
        Connection conn = null;

        String url = "jdbc:mysql://varundevanga09.cikeys.com:3306/varundev_imdb";
        String username = "varundev_varundevanga";
        String pass = "Vinny&varu2";

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, pass);
        }catch(Exception e){
            System.out.println("Error getConnection : " + e.getMessage());
        }

        return conn;
    }

    @Override
    public int createMovie(Movie movie) {
        String query = "INSERT INTO Movies(movie_id, movie_title, imdb_score, title_year,"+
        "movie_imdb_link, movie_facebook_likes) VALUES(?,?,?,?,?,?)";

		Connection conn = null;
		int flag = 0;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, movie.getMovieID());
			ps.setString(2, movie.getMovieTitle());
			ps.setDouble(3, movie.getImdbScore());
			ps.setInt(4, movie.getTitleYear());
			ps.setString(5, movie.getImdbLink());
			ps.setInt(7, movie.getFblikes());

			flag = ps.executeUpdate();
			ps.close();
		} catch(SQLException e) {
			System.out.println("Exception: createMovie(): " + e.getMessage());
		} finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					System.out.println("Exception: createMovie(): " + e.getMessage());
				}
			}
		}
		
		return flag;
    }

    @Override
    public List<Movie> getMoviesLst() {
        String query = "SELECT movie_id, movie_title, imdb_score,title_year, movie_imdb_link,movie_facebook_likes FROM Movies LIMIT 10";
        List<Movie> movieList = new ArrayList<Movie>();
        Connection conn = null;

        try {
            conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieID(rs.getInt("movie_id"));
                movie.setMovieTitle(rs.getString("movie_title"));
                movie.setImdbScore(rs.getDouble("imdb_score"));
                movie.setTitleYear(rs.getInt("title_year"));
                movie.setImdbLink(rs.getString("movie_imdb_link"));
                movie.setFblikes(rs.getInt("movie_facebook_likes"));

                movieList.add(movie);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            System.out.println("error: getMovies() error: " + e.getMessage());
        }
        finally {
            if(conn != null){
                try {
                    conn.close();
                } catch (Exception e) {
                    System.out.println("error: "+e.getMessage());
                }
            }
        }


        return movieList;
    }

    @Override
    public List<Movie> searchMovies(String inputTitle) {
        String query = "SELECT movie_id, movie_title, imdb_score, title_year, movie_imdb_link, movie_facebook_likes FROM Movies WHERE movie_title LIKE '%"+inputTitle+"%'";
        List<Movie> movieList = new ArrayList<Movie>();
        Connection conn = null;

        try {
            conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieID(rs.getInt("movie_id"));
                movie.setMovieTitle(rs.getString("movie_title"));
                movie.setImdbScore(rs.getDouble("imdb_score"));
                movie.setTitleYear(rs.getInt("title_year"));
                movie.setImdbLink(rs.getString("movie_imdb_link"));
                movie.setFblikes(rs.getInt("movie_facebook_likes"));

                movieList.add(movie);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            System.out.println("error: getMovies() error: " + e.getMessage());
        }
        finally {
            if(conn != null){
                try {
                    conn.close();
                } catch (Exception e) {
                    System.out.println("error: "+e.getMessage());
                }
            }
        }


        return movieList;
    }

    @Override
    public Movie getMovieById(int movieID) {

        String query = "SELECT movie_id, movie_title, imdb_score, title_year, movie_imdb_link, movie_facebook_likes FROM Movies WHERE movie_id=?";
        Connection conn = null;
		Movie movie = null;

		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, movieID);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				movie = new Movie(rs.getInt("movie_id"), rs.getString("movie_title"), rs.getDouble("imdb_score"),
						rs.getInt("title_year"), rs.getString("movie_imdb_link"), rs.getInt("movie_facebook_likes"));
			}

			rs.close();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: getMovieById(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: getMovieById(): " + e.getMessage());
				}
			}
		}

		return movie;

    }

    @Override
    public int updateMovie(Movie movie) {
        String query = "UPDATE Movies SET movie_title=?, imdb_score=?, title_year=?, movie_imdb_link=?, movie_facebook_likes=? WHERE movie_id=?";
		Connection conn = null;

		int flag = 0;

		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, movie.getMovieTitle());
			ps.setDouble(2, movie.getImdbScore());
			ps.setInt(3, movie.getTitleYear());
			ps.setString(4, movie.getImdbLink());
            ps.setInt(6, movie.getFblikes());
			ps.setInt(7, movie.getMovieID());

			flag = ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: updateMovie(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: updateMovie(): " + e.getMessage());
				}
			}
		}

		return flag;
    }

    @Override
    public int deleteMovie(int movieID) {
        String query = "DELETE FROM Movies WHERE movie_id=?";
		Connection conn = null;
		int flag = 0;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, movieID);
			flag = ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: deleteMovie(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: deleteMovie(): " + e.getMessage());
				}
			}
		}

		return flag;
    }
    
}
