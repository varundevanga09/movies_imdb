package Movie;

import java.util.List;

public interface MovieDao {
    
    public int createMovie(Movie movie);
    public List<Movie> getMoviesLst();
    public List<Movie> searchMovies(String inputTitle);
    public Movie getMovieById(int movieID);
    public int updateMovie(Movie movie);
    public int deleteMovie(int movieID);

}
