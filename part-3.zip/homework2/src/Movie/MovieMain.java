package Movie;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class MovieMain {

    private MovieDaoImpl mDao;
    
    public MovieMain() {
        mDao = new MovieDaoImpl();
    }


    public void main() throws Exception {

        Scanner sc = new Scanner(System.in);

        boolean exitflag = false;
        while (exitflag != true) {
            System.out.println("\n\tWelcome to  Movie Table");
            System.out.println("Enter 1 to Get 10 Movies");
            System.out.println("Enter 2 to CREATE new movie");
            System.out.println("Enter 3 to UPDATE movie");
            System.out.println("Enter 4 to DELETE movie");
            System.out.println("Enter 5 to search for a movie");
            System.out.println("Enter 9 to Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Top 10 movies (wrt to likes) :- \n");
                    listMovies();
                    break;

                case 2:
                    insertNewMovie();
                    break;

                case 3:
                    System.out.println("\nEnter ID of the movie to be updated");
                    int updMovieID = sc.nextInt();
                    updateMovie(updMovieID);
                    break;

                case 4:
                    System.out.print("\nEnter ID of the movie to be deleted : ");
                    int delMovieID = sc.nextInt();
                    deleteMovie(delMovieID);
                    break;
                
                case 5:
                    System.out.print("Enter title to search : ");
                    String input = sc.next();
                    searchMovie(input);
                    break; 

                case 9:
                    System.out.println("Exiting -- Movie Table");
                    exitflag = true;
                    break;

                default:
                    System.out.println("Incorrect Input");
                    break;
            }
        }

    }

    private void searchMovie(String input) {
        List<Movie> movieList = mDao.searchMovies(input);
        for (Object movie : movieList) {
            System.out.println(movie);
        }
    }


    private void deleteMovie(int delMovieID) {
        int flag = mDao.deleteMovie(delMovieID);
        if (flag > 0)
            System.out.println("Successfully Deleted Movie");
        else
            System.out.println("Error deleting");
    }

    private void updateMovie(int updMovieID) {
        Movie currentMovie = mDao.getMovieById(updMovieID);
        String IMDBlink = currentMovie.getImdbLink();
        String Title = currentMovie.getMovieTitle();
        int TitleYear = currentMovie.getTitleYear();
        double imdbScore = currentMovie.getImdbScore();
        int fblikes = currentMovie.getFblikes();

        Scanner sc2 = new Scanner(System.in);

        boolean exitflag = false;
        try {
            while (exitflag != true) {
                System.out.println("\tWhat column do you want to update:");
                System.out.println("\tEnter 1 for Title");
                System.out.println("\tEnter 2 for TitleYear");
                System.out.println("\tEnter 3 for imdb score");
                System.out.println("\tEnter 4 for FBLikes");
                System.out.println("\tEnter 9 to UPDATE THE FIELDS");
                System.out.println("\tEnter 10 for Exit and update nothing");
                int choice = sc2.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("\nOld value of title : " + Title);
                        System.out.print("Enter new value :- ");
                        Title = sc2.next();
                        break;

                    case 2:
                        System.out.println("\nOld value of TitleYear : " + TitleYear);
                        System.out.print("Enter new value :- ");
                        TitleYear = sc2.nextInt();
                        break;

                    case 3:
                        System.out.println("\nOld value of imdb score : " + imdbScore);
                        System.out.print("Enter new value :- ");
                        imdbScore = sc2.nextInt();
                        break;

                    case 4:
                        System.out.println("\nOld value of Fblikes : " + fblikes);
                        System.out.print("Enter new value :- ");
                        fblikes = sc2.nextInt();
                        break;

                    case 9:
                        // System.out.println(Title+" : "+TitleYear+" : "+Duration+" : "+Language+" :
                        // "+fblikes);
                        Movie movieUpdates = new Movie(updMovieID, Title, imdbScore, TitleYear, IMDBlink, fblikes);
                        mDao.updateMovie(movieUpdates);
                        break;

                    case 10:
                        System.out.println("\tExiting - Update");
                        exitflag = true;
                        break;

                    default:
                        System.out.println("Invalid entry");
                        break;
                }
            }

        } catch (Exception e) {
            System.out.println("Error: invalid input");
        }
    }

    private void insertNewMovie() throws IOException {
        Scanner sc3 = new Scanner(System.in);
        int MovieID = 0;
        String IMDBlink = "";
        String Title = "";
        int TitleYear = 0;
        double imdbScore = 0;
        int fblikes = 0;
        try {
            System.out.print("\tEnter Movie movieID:- ");
            MovieID = sc3.nextInt();
            System.out.print("\tEnter Movie imdb link:- ");
            IMDBlink = sc3.next();
            System.out.print("\tEnter Movie title:- ");
            Title = sc3.next();
            System.out.print("\tEnter Movie title year:- ");
            TitleYear = sc3.nextInt();
            System.out.print("\tEnter imdb score duration:- ");
            imdbScore = sc3.nextDouble();
            System.out.print("\tEnter Movie fblikes:- ");
            fblikes = sc3.nextInt();
        } catch (Exception e) {
            System.out.println("Error: invalid input");
        }

        Movie newMovie = new Movie(MovieID, Title, imdbScore, TitleYear, IMDBlink, fblikes);

        mDao.createMovie(newMovie);
    }

    private void listMovies() {
        List<Movie> movieList = mDao.getMoviesLst();

        for (Object movie : movieList) {
            System.out.println(movie);
        }
    }

}
