package Movie;

public class Movie {

    int movieID;
    String movieTitle;
    double imdbScore;
    int titleYear;
    String imdbLink;
    int fblikes;

    public Movie() { super(); }


    public Movie(int movieID, String movieTitle, double imdbScore, int titleYear, String imdbLink, int fblikes)
   {
        super();
        this.movieID = movieID;
        this.movieTitle = movieTitle;
        this.imdbScore = imdbScore;
        this.titleYear = titleYear;
        this.imdbLink = imdbLink;
        this.fblikes = fblikes;
    }

    @Override
	public String toString() {
        return "Movie [movieID="+movieID+ ", title="+ movieTitle +", imdbscore="+imdbScore+", titleYear="+titleYear+", imdbLink="+imdbLink+", fblikes="+fblikes+"]\n";
	}

    public int getMovieID() {
        return this.movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }

    public String getMovieTitle() {
        return this.movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public double getImdbScore() {
        return this.imdbScore;
    }

    public void setImdbScore(double imdbScore) {
        this.imdbScore = imdbScore;
    }

    public int getTitleYear() {
        return this.titleYear;
    }

    public void setTitleYear(int string) {
        this.titleYear = string;
    }

    public String getImdbLink() {
        return this.imdbLink;
    }

    public void setImdbLink(String imdbLink) {
        this.imdbLink = imdbLink;
    }

    public int getFblikes() {
        return this.fblikes;
    }

    public void setFblikes(int fblikes) {
        this.fblikes = fblikes;
    }


    
}
