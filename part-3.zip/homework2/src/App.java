import java.util.Scanner;

import Genre.GenreMain;
import Movie.MovieMain;

public class App {
    
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        MovieMain movieMain = new MovieMain();
        GenreMain genreMain = new GenreMain();
        
        boolean exitflag = false;
        while (exitflag != true) {
            System.out.println("\n\n\nWelcome to IMDb Movie Dataset");
            System.out.println("Enter 1 to work on MOVIE Table");
            System.out.println("Enter 2 to work on GENRES Table");
            System.out.println("Enter 9 to Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    movieMain.main();
                    break;

                case 2:
                    genreMain.main();
                    break;


                case 9:
                    System.out.println("Thank you");
                    exitflag = true;
                    break;

                default:
                    System.out.println("Incorrect Input");
                    break;
            }
        }

        sc.close();
        
    }
}
