package Genre;

import java.util.List;

public interface  GenreDao {
    public int createGenre(Genre Genre);
    public List<Genre> getGenre();
    public List<Genre> searchGenre(String inputTitle);
    public Genre getGenreById(int GenreID);
    public int updateGenre(Genre Genre);
    public int deleteGenre(int GenreID);
}
