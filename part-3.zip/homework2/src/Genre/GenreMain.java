package Genre;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class GenreMain {

    private GenreDaoImpl gDao;

    public GenreMain() {
        gDao = new GenreDaoImpl();
    }

    public void main() throws Exception {

        Scanner sc = new Scanner(System.in);

        boolean exitflag = false;
        while (exitflag != true) {
            System.out.println("\n\tWelcome to  Genre Table");
            System.out.println("Enter 1 to Get 10 Genres");
            System.out.println("Enter 2 to CREATE new genre");
            System.out.println("Enter 3 to UPDATE genre");
            System.out.println("Enter 4 to DELETE genre");
            System.out.println("Enter 5 to search for a genre");
            System.out.println("Enter 9 to Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Top 10 genres (wrt to likes) :- \n");
                    listGenre();
                    break;

                case 2:
                    insertNewGenre();
                    break;

                case 3:
                    System.out.println("\nEnter ID of the genre to be updated");
                    int genreId = sc.nextInt();
                    updateGenre(genreId);
                    break;

                case 4:
                    System.out.print("\nEnter ID of the genre to be deleted : ");
                    int delGenreId = sc.nextInt();
                    deleteGenre(delGenreId);
                    break;

                case 5:
                    System.out.print("Enter title to search : ");
                    String input = sc.next();
                    searchGenre(input);
                    break;

                case 9:
                    System.out.println("Exiting -- Genre Table");
                    exitflag = true;
                    break;

                default:
                    System.out.println("Incorrect Input");
                    break;
            }
        }

    }

    private void searchGenre(String input) {
        List<Genre> movieList = gDao.searchGenre(input);
        for (Object movie : movieList) {
            System.out.println(movie);
        }
    }

    private void deleteGenre(int delMovieID) {
        int flag = gDao.deleteGenre(delMovieID);
        if (flag > 0)
            System.out.println("Successfully Deleted genre");
        else
            System.out.println("Error deleting");
    }

    private void updateGenre(int updGenreID) {
        Genre currentMovie = gDao.getGenreById(updGenreID);
        String genre_name = currentMovie.getGenres();

        Scanner sc2 = new Scanner(System.in);

        boolean exitflag = false;
        try {
            while (exitflag != true) {
                System.out.println("\tWhat column do you want to update:");
                System.out.println("\tEnter 1 for Title");
                System.out.println("\tEnter 9 to UPDATE THE FIELDS");
                System.out.println("\tEnter 10 for Exit and update nothing");
                int choice = sc2.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("\nOld value of genre : " + genre_name);
                        System.out.print("Enter new value :- ");
                        genre_name = sc2.next();
                        break;

                    case 9:
                        // System.out.println(Title+" : "+TitleYear+" : "+Duration+" : "+Language+" :
                        // "+fblikes);
                        Genre genre = new Genre(updGenreID, genre_name);
                        gDao.updateGenre(genre);
                        break;

                    case 10:
                        System.out.println("\tExiting - Update");
                        exitflag = true;
                        break;

                    default:
                        System.out.println("Invalid entry");
                        break;
                }
            }

        } catch (Exception e) {
            System.out.println("Error: invalid input");
        }
    }

    private void insertNewGenre() throws IOException {
        Scanner sc3 = new Scanner(System.in);
        int genreID = 0;
        String genre_name = "";

        try {
            System.out.print("\tEnter genre genreID:- ");
            genreID = sc3.nextInt();
            System.out.print("\tEnter genre imdb link:- ");
            genre_name = sc3.next();

        } catch (Exception e) {
            System.out.println("Error: invalid input");
        }

        Genre genre = new Genre(genreID, genre_name);

        gDao.createGenre(genre);
    }

    private void listGenre() {
        List<Genre> geList = gDao.getGenre();

        for (Object its : geList) {
            System.out.println(its);
        }
    }

}
