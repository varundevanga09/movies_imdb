package Genre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class GenreDaoImpl implements GenreDao
{
    public GenreDaoImpl () {};
    protected Connection getConnection() throws SQLException {
        Connection conn = null;

        String url = "jdbc:mysql://varundevanga09.cikeys.com:3306/varundev_imdb";
        String username = "varundev_varundevanga";
        String pass = "Vinny&varu2";

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, pass);
        }catch(Exception e){
            System.out.println("Error getConnection : " + e.getMessage());
        }

        return conn;
    }
    
    @Override
    public int createGenre(Genre genre) {
        String query = "INSERT INTO Genres(genre_id, genres) VALUES(?,?)";

		Connection conn = null;
		int flag = 0;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, genre.getGenreID());
			ps.setString(2, genre.getGenres());
			flag = ps.executeUpdate();
			ps.close();
		} catch(SQLException e) {
			System.out.println("Exception: createMovie(): " + e.getMessage());
		} finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					System.out.println("Exception: createMovie(): " + e.getMessage());
				}
			}
		}
		
		return flag;
    }

    @Override
    public List<Genre> getGenre() {
        String query = "SELECT genre_id, genres FROM Genres LIMIT 10";
        List<Genre> GenreList = new ArrayList<Genre>();
        Connection conn = null;

        try {
            conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Genre genre = new Genre();
                genre.setGenreID(rs.getInt("genre_id"));
                genre.setGenres(rs.getString("genres"));

                GenreList.add(genre);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            System.out.println("error: getGenres() error: " + e.getMessage());
        }
        finally {
            if(conn != null){
                try {
                    conn.close();
                } catch (Exception e) {
                    System.out.println("error: "+e.getMessage());
                }
            }
        }


        return GenreList;
    }
    @Override
    public List<Genre> searchGenre(String inputTitle) {
        String query = "SELECT genre_id, genres FROM Genres WHERE genres LIKE '%"+inputTitle+"%'";
        List<Genre> GenreList = new ArrayList<Genre>();
        Connection conn = null;

        try {
            conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Genre genre = new Genre();
                genre.setGenreID(rs.getInt("genre_id"));
                genre.setGenres(rs.getString("genres"));
                

                GenreList.add(genre);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            System.out.println("error: getGenres() error: " + e.getMessage());
        }
        finally {
            if(conn != null){
                try {
                    conn.close();
                } catch (Exception e) {
                    System.out.println("error: "+e.getMessage());
                }
            }
        }


        return GenreList;
    }

    @Override
    public Genre getGenreById(int genreID) {

        String query = "SELECT genre_id, genres FROM Genres WHERE genre_id=?";
        Connection conn = null;
		Genre genre = null;

		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, genreID);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				genre = new Genre(rs.getInt("genre_id"), rs.getString("genres"));
			}

			rs.close();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: getGenreById(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: getGenreById(): " + e.getMessage());
				}
			}
		}

		return genre;

    }

    @Override
    public int updateGenre(Genre genre) {
        String query = "UPDATE Genres SET genres =? WHERE genre_id=?";
		Connection conn = null;

		int flag = 0;

		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, genre.getGenres());
			ps.setInt(2, genre.getGenreID());

			flag = ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: updateGenre(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: GenreMovie(): " + e.getMessage());
				}
			}
		}

		return flag;
    }
    @Override
    public int deleteGenre(int genreID) {
        String query = "DELETE FROM Genres WHERE genre_id=?";
		Connection conn = null;
		int flag = 0;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, genreID);
			flag = ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Exception: deleteGenre(): " + e.getMessage());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Exception: deleteGenre(): " + e.getMessage());
				}
			}
		}

		return flag;
    }
}
