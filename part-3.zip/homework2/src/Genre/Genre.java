package Genre;
 public class Genre {

    int genreID;
    String genres;
    public Genre() { super(); }
    public Genre(int genreID, String genres)
    {
        super();
        this.genreID = genreID;
        this.genres = genres;
    }

    @Override
    public String toString() {
        return "Genre [genreID="+genreID+ ", genres="+ genres +"]\n";
	}

    public int getGenreID() {
        return this.genreID;
    }

    public void setGenreID(int genreID) {
        this.genreID = genreID;
    }

    public String getGenres() {
        return this.genres;
    }

    public void setGenres(String inpt) {
        this.genres =inpt;
    }


}
 